function submitForm() {
    // Retrieve form values
    var idNumber = document.getElementById('idNumber').value;
    var firstName = document.getElementById('firstName').value;
    var lastName = document.getElementById('lastName').value;
    var dob = document.getElementById('dob').value;
    var salary = document.getElementById('salary').value;
    var gender = document.getElementById('gender').value;
    var isEligible = document.getElementById('isEligible').checked;
    var username = document.getElementById('username').value;
    var department = document.getElementById('department').value;

    // Validation functions
    function isNumeric(value) {
        return /^\d+$/.test(value);
    }

    function isAlphabetic(value) {
        return /^[a-zA-Z]+$/.test(value);
    }

    function isValidDate(value) {
        // Validate date format (dd-mm-yyyy)
        var dateRegex = /^\d{2}-\d{2}-\d{4}$/;
        return dateRegex.test(value);
    }

    function isDouble(value) {
        return /^-?\d+(\.\d+)?$/.test(value);
    }

    function isAlphanumericWithSpecialChars(value) {
        return /^[a-zA-Z0-9_\-\.]+$/.test(value);
    }

    // Basic validation
    if (!isNumeric(idNumber) || !isAlphabetic(firstName) || !isAlphabetic(lastName) || !isValidDate(dob) || !isDouble(salary) || !isAlphanumericWithSpecialChars(username)) {
        alert("Invalid input. Please check the form fields.");
        return;
    }

    // Additional validations
    // Implement additional validations based on your specific requirements

    // Simulate HTTP API call (replace with actual API call)
    var registrationData = {
        idNumber: idNumber,
        firstName: firstName,
        lastName: lastName,
        dob: dob,
        salary: salary,
        gender: gender,
        isEligible: isEligible,
        username: username,
        department: department
    };

    // Assuming you have an API endpoint /api/register in your Spring Boot backend
    fetch('http://localhost:8080/api/registrations/register', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(registrationData),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.text(); // Change to response.text() to handle non-JSON responses
    })
    .then(data => {
        try {
            var jsonData = JSON.parse(data);
            console.log('Success:', jsonData);
            alert('Registration successful');
            document.getElementById('registrationForm').reset();
        } catch (jsonError) {
            console.error('JSON parsing error:', jsonError);
            alert('Registration successful, but there was an issue parsing the response. Please check the console for details.');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Registration failed. Please check the console for details.');
    });
}
