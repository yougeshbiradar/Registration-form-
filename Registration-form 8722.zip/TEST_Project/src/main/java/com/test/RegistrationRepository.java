package com.test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class RegistrationRepository {
    @Autowired
    private JdbcTemplate jdbcTemplate;

    public void save(Registration registration) {
        String sql = "INSERT INTO Registration (id, first_name, last_name, dob, salary, gender, is_eligible, username, department) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        jdbcTemplate.update(
                sql,
                registration.getId(),
                registration.getFirstName(),
                registration.getLastName(),
                registration.getDob(),
                registration.getSalary(),
                String.join(",", registration.getGender()), // Assuming gender is a list of strings
                registration.getIsEligible(),
                registration.getUsername(),
                String.join(",", registration.getDepartment()) // Assuming department is a list of strings
        );
    }
}
