package com.test;
import java.util.Date;
import java.util.List;
public class Registration {

	private Integer id;
    private String firstName;
    private String lastName;
    private Date dob;
    private Double salary;
    private List<String> gender;
    private Boolean isEligible;
    private String username;
    private List<String> department;

    // Constructors, getters, and setters

    public Registration() {
        // Default constructor
    }

    public Registration(Integer id, String firstName, String lastName, Date dob, Double salary, List<String> gender, Boolean isEligible, String username, List<String> department) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.dob = dob;
        this.salary = salary;
        this.gender = gender;
        this.isEligible = isEligible;
        this.username = username;
        this.department = department;
    }

    // Getters and setters

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public Double getSalary() {
        return salary;
    }

    public void setSalary(Double salary) {
        this.salary = salary;
    }

    public List<String> getGender() {
        return gender;
    }

    public void setGender(List<String> gender) {
        this.gender = gender;
    }

    public Boolean getIsEligible() {
        return isEligible;
    }

    public void setIsEligible(Boolean isEligible) {
        this.isEligible = isEligible;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public List<String> getDepartment() {
        return department;
    }

    public void setDepartment(List<String> department) {
        this.department = department;
    }

    @Override
    public String toString() {
        return "RegistrationPojo{" +
                "id=" + id +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", dob=" + dob +
                ", salary=" + salary +
                ", gender=" + gender +
                ", isEligible=" + isEligible +
                ", username='" + username + '\'' +
                ", department=" + department +
                '}';
    }
}