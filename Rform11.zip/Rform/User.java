package com.user.details.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;


@Entity
@Table(name = "Form")
public class User {

    @Id()
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    private String firstName;
    private String lastfirstName;
    private String dob;
    private int salary;
    private String gender;
    private String isEligible;
   private String userfirstName;
   private String departament;


    //Parameterized constructor
    public User(int id,  String firstName
    , String lastfirstName,
     String dob,
     int salary,
     String gender,
     String isEligible,
    String userfirstName,
    String departament) {
        this.id = id;
        this.firstName = firstName;
        this.lastfirstName = lastfirstName;
        this.dob = dob;
        this.gender = gender;
        this.isEligible = isEligible;
        this.userfirstName = userfirstName;
        this.departament = departament;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastfirstName() {
        return lastfirstName;
    }

    public void setLastfirstName(String lastfirstName) {
        this.lastfirstName = lastfirstName;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public int getSalary() {
        return salary;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getIsEligible() {
        return isEligible;
    }

    public void setIsEligible(String isEligible) {
        this.isEligible = isEligible;
    }

    public String getUserfirstName() {
        return userfirstName;
    }

    public void setUserfirstName(String userfirstName) {
        this.userfirstName = userfirstName;
    }

    public String getDepartament() {
        return departament;
    }

    public void setDepartament(String departament) {
        this.departament = departament;
    }

    public User() {
    }

    //Getter  and Setter
    public int getId() {
        return id;
    }

   
    //To String method
    @Override
    public String toString() {
        return "User [id=" + id + ", firstName=" + firstName + ", lastfirstName=" + lastfirstName + ", dob=" + dob + ", gender=" + gender
                + ", isEligible=" + isEligible + ", userfirstName=" + userfirstName + ", departament=" + departament+"]";
    }
   
}
