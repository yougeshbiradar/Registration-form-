package com.user.details.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.user.details.UserDao.UserRepository;
import com.user.details.entities.User;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

   // Get All Users
    public List<User> getAllUser(){
        List<User> list = this.userRepository.findAll();
        return list;
    }

    // Save User
    public void addUser(User user){
        this.userRepository.save(user);
    }

    // Delete user
    public void deleteUser(int id){
        this.userRepository.deleteById(id);
    }

    //Update the user
    public void updateUser(User user, int id){
        user.setId(id);
        userRepository.save(user);
    }
    
}
